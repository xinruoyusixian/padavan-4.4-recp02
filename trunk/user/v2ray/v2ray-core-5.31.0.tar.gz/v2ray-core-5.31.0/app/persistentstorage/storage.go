package persistentstorage

import "github.com/v2fly/v2ray-core/v5/features/extension/storage"

type ScopedPersistentStorage = storage.ScopedPersistentStorage
